<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="proses.php">
    <label for="nama">Nama pasien:</label>
    <input type="text" id="nama" name="nama">

    <label for="tensi">tensi:</label>
    <input type="number" id="tensi" name="tensi">

    <button type="submit">Submit</button>
</form>

</body>
</html>