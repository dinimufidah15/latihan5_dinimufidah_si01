<?php

class pasien {
    private $nama;
    private $tensi;

    public function __construct($nama, $tensi) {
        $this->nama = $nama;
        $this->tensi = $tensi;
    }

    public function getNama() {
        return $this->nama;
    }

    public function getTensi() {
        return $this->tensi;
    }

    public function hasilSehat() {
        return $this->tensi >= 60 ? 'sehat' : 'Tidak sehat';
    }

    public function predikat() {
        if ($this->tensi >= 90) {
            return 'darah tinggi';
        } elseif ($this->tensi >= 50) {
            return 'darah rendah';
        } elseif ($this->tensi >= 70) {
            return 'normal';
        } else {
            return 'cukup';
        }
    }
}
